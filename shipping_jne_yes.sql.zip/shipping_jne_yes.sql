-- phpMyAdmin SQL Dump
-- version 3.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1:33066
-- Generation Time: Nov 08, 2013 at 07:50 PM
-- Server version: 5.1.65
-- PHP Version: 5.3.15

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `sementara`
--

-- --------------------------------------------------------

--
-- Table structure for table `shipping_jne_yes`
--

CREATE TABLE IF NOT EXISTS `shipping_jne_yes` (
  `city` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `state` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `price` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='JNE Shippinh YES Price';

--
-- Dumping data for table `shipping_jne_yes`
--

INSERT INTO `shipping_jne_yes` (`city`, `state`, `price`) VALUES
('Medan', 'Sumatera Utara', 24000),
('Belawan', 'Sumatera Utara', 30500),
('Pekanbaru', 'Riau', 23000),
('Batam', 'Kepulauan Riau', 23000),
('Padang', 'Sumatera Barat', 22000),
('Jambi', 'Jambi', 22000),
('Palembang', 'Sumatera Selatan', 20000),
('Pangkal Pinang', 'Bangka Belitung', 22000),
('Bengkulu', 'Bengkulu', 22000),
('Bandar Lampung', 'Lampung', 16500),
('Jakarta', 'DKI Jakarta', 14000),
('Tangerang', 'Tangerang', 14500),
('Tigaraksa', 'Tangerang', 16000),
('Balaraja', 'Tangerang', 16000),
('Serpong/BSD', 'Tangerang', 16000),
('Ciledug', 'Tangerang', 16000),
('Pamulang', 'Tangerang', 16000),
('Bandung', 'Jawa Barat', 16000),
('Banjar', 'Jawa Barat', 19000),
('Bekasi', 'Jawa Barat', 14000),
('Bogor', 'Jawa Barat', 14000),
('Ciamis', 'Jawa Barat', 20000),
('Cianjur', 'Jawa Barat', 15000),
('Cibinong', 'Jawa Barat', 17000),
('Cikarang', 'Jawa Barat', 16000),
('Cimahi', 'Jawa Barat', 17000),
('Cirebon', 'Jawa Barat', 15000),
('Depok', 'Jawa Barat', 14000),
('Garut', 'Jawa Barat', 17000),
('Indramayu', 'Jawa Barat', 21000),
('Karawang', 'Jawa Barat', 16000),
('Kuningan', 'Jawa Barat', 21000),
('Ngamprah/Cimareme/Padalar', 'Jawa Barat', 21000),
('Soreang', 'Jawa Barat', 20000),
('Sukabumi', 'Jawa Barat', 15000),
('Sumedang', 'Jawa Barat', 20000),
('Tasikmalaya', 'Jawa Barat', 19000),
('Majalaya', 'Jawa Barat', 20000),
('Jatinangor', 'Jawa Barat', 18000),
('Lembang', 'Jawa Barat', 20000),
('Rancaekek', 'Jawa Barat', 20000),
('Jatibarang', 'Jawa Barat', 21000),
('Boyolali', 'Jawa Barat', 21000),
('Karanganyar', 'Jawa Barat', 20000),
('Kendal', 'Jawa Barat', 21000),
('Klaten', 'Jawa Barat', 18000),
('Kudus', 'Jawa Barat', 21000),
('Salatiga', 'Jawa Barat', 20000),
('Semarang', 'Jawa Barat', 16000),
('Sragen', 'Jawa Barat', 21000),
('Sukoharjo', 'Jawa Barat', 21000),
('Surakarta/Solo', 'Jawa Barat', 16000),
('Ungaran', 'Jawa Barat', 17000),
('Wonogiri', 'Jawa Barat', 21000),
('Ambarawa', 'Jawa Barat', 21000),
('Kartosuro', 'Jawa Barat', 21000),
('Bantul', 'D.I. Yogyakarta', 20000),
('Sleman', 'D.I. Yogyakarta', 20000),
('Wates/Kulon Progo', 'D.I. Yogyakarta', 18000),
('Wonosari', 'D.I. Yogyakarta', 18000),
('Yogyakarta', 'D.I. Yogyakarta', 15000),
('Prambanan', 'D.I. Yogyakarta', 20000),
('Gresik', 'Jawa Timur', 22000),
('Jombang', 'Jawa Timur', 23000),
('Lamongan', 'Jawa Timur', 24000),
('Malang', 'Jawa Timur', 19000),
('Mojokerto', 'Jawa Timur', 19000),
('Pandaan', 'Jawa Timur', 23000),
('Probolinggo', 'Jawa Timur', 23000),
('Sidoarjo', 'Jawa Timur', 21000),
('Surabaya', 'Jawa Timur', 16000),
('Tuban', 'Jawa Timur', 23000),
('Denpasar', 'Bali', 19000),
('Kuta', 'Bali', 23000),
('Nusa Dua', 'Bali', 23000),
('Sanur', 'Bali', 23000),
('Pontianak', 'Kalimantan Barat', 25000),
('Banjarmasin', 'Kalimantan Selatan', 25000),
('Palangkaraya', 'Kalimantan Tengah', 26500),
('Balikpapan', 'Kalimantan Timur', 30000),
('Makassar', 'Sulawesi Selatan', 30500),
('Mataram', 'Nusa Tenggara Barat', 24000);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
